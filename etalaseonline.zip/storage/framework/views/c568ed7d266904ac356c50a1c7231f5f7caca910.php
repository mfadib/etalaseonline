<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12 p10">
			<?php foreach($content->get() as $item): ?>

			<?php $__env->startSection('titlebar'); ?>
			      <div class="row">
			        <div class="container">
			          <div class="col-md-12 p10">
			            <ol class="breadcrumb">
			              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('HomeController@index')); ?>" class="cb">Home</a></li>
			              <li class="breadcrumb-item active"><b><?php echo e($item->title); ?></b></li>
			            </ol>
			          </div>
			        </div>
			      </div>
			<?php $__env->stopSection(); ?>

				<?php if($item->image != ''): ?>
					<img src="<?php echo e(url('images/pages/'.$item->image)); ?>" alt="<?php echo e($item->title); ?>" class="img img-thumbnail img-responsive">
				<?php endif; ?>
				<?php echo $item->description; ?>

			<?php endforeach; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>