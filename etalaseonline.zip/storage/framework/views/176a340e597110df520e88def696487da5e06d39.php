<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Subscribes</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th style="width:40%;">Email</th>
							<th style="width:30%;">Unique Code</th>
							<th style="width:15%;">Status</th>
							<th style="width:15%;">Joined</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($subscribes as $item): ?>
						<tr>
							<td><?php echo $item->email; ?></td>
							<td><?php echo $item->unique_code; ?></td>
							<td><?php echo e($query->get_status($item->status)); ?></td>
							<td><?php echo e(date('d, M Y',strtotime($item->created_at))); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $subscribes->links();; ?>

			</div>
		</div>	
		<br><br><br>&nbsp;
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>