<?php $__env->startSection('titlebar'); ?>
      <div class="row">
        <div class="container">
          <div class="col-md-12 p10">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('HomeController@index')); ?>" class="cb">Home</a></li>
              <li class="breadcrumb-item active"><b>Products</b></li>
            </ol>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
	<div class="row">
            <?php if(Auth::check()): ?>
              <?php if(Auth::user()->status == 0): ?>
                <?php $__env->startSection('sidebar_left'); ?>

		            <div style="border: 1px solid #ccc">
  						<div class="f16 bg p10 cw">CATEGORY</div>
		            	<div class="p10">
							<div><a href="<?php echo e(url('products')); ?>">All Category (<?php echo e($query->get_data('products')->count()); ?>)</a></div>
							<?php foreach($categories as $item): ?>
							<div><a href="<?php echo e(url('product/category/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($query->get_data('products',['category_id'=>$item->id])->count()); ?>)</a></div>
							<?php endforeach; ?>
		              	</div>
		            </div>
				<?php $__env->stopSection(); ?>
              <?php endif; ?>
          		<div class="col-md-12 col-xs-12 p10" style="margin-top: -20px">
            <?php else: ?>
	          <div class="col-md-3 top-nav">
	            <div style="border: 1px solid #ccc">
	            	<div class="f16 bg p10 cw">CATEGORY</div>
	            	<div class="p10">
						<div><a href="<?php echo e(url('products')); ?>">All Category (<?php echo e($query->get_data('products')->count()); ?>)</a></div>
						<?php foreach($categories as $item): ?>
						<div><a href="<?php echo e(url('product/category/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($query->get_data('products',['category_id'=>$item->id])->count()); ?>)</a></div>
						<?php endforeach; ?>
	              	</div>
	            </div>
	          </div>
          		<div class="col-md-9 col-xs-12 p10" style="margin-top: -20px">
            <?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<?php foreach($product->get() as $pro): ?>
					<h3><?php echo e($pro->title); ?> <span class="pull-right"><?php echo e($query->currency_format($pro->price)); ?></span></h3><hr>
					<div class="row">
						<div class="col-md-5">
							<img src="<?php echo e(url('images/products/'.$pro->cover)); ?>" class="img img-thumbnail img-resposive" alt="<?php echo e($pro->title); ?>">
							<?php /* <?php if($images->count() != 0): ?>
							<div class="row">
								<?php foreach($images->get() as $item): ?>
				              	<div class="col-sm-4 col-xs-6">
				                	<img id="zoom" src="<?php echo e(URL::asset($item->image)); ?>" style="width: 100%;" class="img-thumbnail img-responsive">
				              	</div>
				              	<?php endforeach; ?>
				            </div>
							<?php endif; ?> */ ?>
						</div>
						<div class="col-md-7">
							<h4>Description</h4>
							<?php echo e($pro->description); ?>

							<hr>
							<a href="<?php echo e(url('product/wishlist/'.$pro->slug)); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-info btn-xs">Wishlist</a>
							<a href="<?php echo e($shares['email']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-envelope-o"></i> Email</a>
							<a href="<?php echo e($shares['facebook']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-facebook"></i> Facebook</a>
							<a href="<?php echo e($shares['twitter']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-twitter"></i> Twitter</a>
							<a href="<?php echo e($shares['gplus']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-google-plus"></i> Google Plus</a>
							
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<br><ul class="nav nav-tabs">
							  	<li><a href="#how_to_buy" data-toggle="tab">How to Buy?</a></li>
							  	<li><a href="#reviews" data-toggle="tab">Reviews</a></li>
							  	<li><a href="#send_review" data-toggle="tab">Send Review</a></li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content"><br>
							  	<div class="tab-pane active" id="how_to_buy"><?php echo e($pro->how_to_buy); ?></div>
							  	<div class="tab-pane" id="reviews">
							  		<?php if($reviews->count() == 0): ?>
										<div class="alert alert-info">
											product dont have reviews
										</div>
									<?php else: ?>
										<?php foreach($reviews->get() as $rev): ?>
										<div class="well">
											<p><?php echo e($query->get_field_data('users',['id'=>$rev->user_id],'name')); ?></p>
											<p>Product: <?php echo e($rev->quality_product); ?> Stars</p>
											<p>Service: <?php echo e($rev->quality_service); ?> Stars</p>
											<p>Message: <?php echo e($rev->message); ?></p>
										</div>
										<?php endforeach; ?>
									<?php endif; ?>
							  	</div>
							  	<div class="tab-pane" id="send_review">
									<?php echo Form::open(['action'=>'ProductController@insert_review','method'=>'post','role'=>'form']); ?>

										<div class="form-group">
						                    <?php echo Form::label('qualityProduct','Quality Product'); ?>

						                    <?php echo Form::hidden('product_id',$pro->id); ?>

						                    <?php echo Form::hidden('product_slug',$pro->slug); ?>

						                    <?php echo Form::select('quality_product',['1'=>'Very Bad','2'=>'Bad','3'=>'Netral','4'=>'Good','5'=>'Very Good'],null,['class'=>'form-control','id'=>'qualityProduct','placeholder'=>'Quality Product']); ?>

						                    <?php if($errors->has()): ?>
						                        <p class="text-danger"><?php echo e($errors->first('quality_product')); ?></p>
						                    <?php endif; ?>
						                </div>
						                <div class="form-group">
						                    <?php echo Form::label('qualityService','Quality Service'); ?>

						                    <?php echo Form::select('quality_service',['1'=>'Very Bad','2'=>'Bad','3'=>'Netral','4'=>'Good','5'=>'Very Good'],null,['class'=>'form-control','id'=>'qualityService','placeholder'=>'Quality Service']); ?>

						                    <?php if($errors->has()): ?>
						                        <p class="text-danger"><?php echo e($errors->first('quality_service')); ?></p>
						                    <?php endif; ?>
						                </div>
						                <div class="form-group">
						                    <?php echo Form::label('message','Message'); ?>

						                    <?php echo Form::textarea('message',null,['class'=>'form-control','id'=>'message','placeholder'=>'Message']); ?>

						                    <?php if($errors->has()): ?>
						                        <p class="text-danger"><?php echo e($errors->first('message')); ?></p>
						                    <?php endif; ?>
						                </div>
               							<?php echo Form::submit('Send',['class'=>'btn btn-default']); ?>

									<?php echo Form::close(); ?>

							  	</div>
							</div>
							<hr>
						</div>
					</div><br>
					<?php endforeach; ?>
				</div>
			</div>

      <!-- Recomended -->

	      <div class="row mt40" style="border-top: 1px solid #666">
	        <center><div class="f16" style="width: 240px; background: #fff; margin-top: -14px;">RELATED PRODUCT</div></center>
	      </div>

	      <div class="row mt20">
	        <div class="container">
	        	<?php foreach($relations->get() as $item): ?>
	          	<div class="col-md-3 col-sm-3 col-xs-6 p10 bordash">
	            	<div class="p10 bg2" style="height: 250px; background: url(<?php echo e(url('images/products/'.$item->cover)); ?>); background-size: cover; background-position: center;"></div>
	            	<div class="tc fprod"><?php echo e($item->title); ?></div>
	            	<div class="tc fprod mt5"><b><?php echo e($query->currency_format($item->price)); ?></b></div>
	          	</div>
				<?php endforeach; ?>
	        </div>
	      </div>
	      <br><br>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>