<p>Hello Subscriber, </p>
<p>To stop subscribe <a href="<?php echo e($url); ?>" title="">click here</a></p>
<p>or copy and paste this url <b><?php echo e($url); ?></b></p>