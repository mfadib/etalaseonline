mailto:?subject=<?php echo e(rawurlencode($title)); ?>&body=<?php echo e(rawurlencode($url)); ?>

