<?php $__env->startSection('h3'); ?>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Product Categories</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-5">
			<h3>Add new category</h3>	
			<?php echo Form::open(['action'=>'AdminController@product_category_insert','method'=>'post','role'=>'form']); ?>

			<div class="form-group">
				<?php echo Form::label('parent','Parent',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
              		<?php echo Form::select('parent',$cats,null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('parent'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('name','name',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('name',null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'name']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('name'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
		<?php echo Form::close(); ?>

		</div>
		<div class="col-md-7">
			<h3>List Category</h3>

			<table class="table">
				<thead>
					<tr>
						<th style="width:40%;">Parent</th>
						<th style="width:40%;">Name</th>
						<th style="width:10%;">Edit</th>
						<th style="width:10%;">Delete</th>
					</tr>
				</thead>
				<tbody>
			<?php foreach($categories->get() as $item): ?>
					<tr>
						<?php echo Form::open(['action'=>'AdminController@product_category_update','method'=>'post']); ?>

						<td>
							<?php echo Form::hidden('id',$item->id); ?>

							<?php echo Form::select('parent',$cats,$item->parent,['class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

						</td>
						<td>
							<?php echo Form::text('name',$item->name,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Name']); ?>

						</td>
						<td>
							<?php echo Form::submit('Edit',['class'=>'btn btn-info']); ?>

						</td>
						<?php echo Form::close(); ?>

						<td>
							<?php echo Form::open(['action'=>'AdminController@product_category_delete','method'=>'post']); ?>

								<?php echo Form::hidden('id',$item->id); ?>

								<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

							<?php echo Form::close(); ?>

						</td>
					</tr>
			<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>