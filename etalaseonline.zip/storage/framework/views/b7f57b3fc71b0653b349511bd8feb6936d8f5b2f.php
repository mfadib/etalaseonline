<?php $__env->startSection('titlebar'); ?>
      <div class="row">
        <div class="container">
          <div class="col-md-12 p10">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('MemberController@memberarea')); ?>" class="cb">Member Area</a></li>
              <li class="breadcrumb-item active"><b>Your Reviews</b></li>
            </ol>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
	<h3>Your reviews</h3>
	<table class="table table-striped">
		<thead>
			<tr>
				<th style="width:50%;">Product Item</th>
				<th style="width:10%;">Product</th>
				<th style="width:10%;">Service</th>
				<th style="width:20%;">Message</th>
				<th style="width:10%;">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($reviews->get() as $item): ?>
				<tr>
					<td><?php echo e($query->get_field_data('products',['id'=>$item->product_id],'title')); ?></td>
					<td><?php echo e($query->get_review($item->quality_product)); ?></td>
					<td><?php echo e($query->get_review($item->quality_service)); ?></td>
					<td><?php echo e($item->message); ?></td>
					<td><a href="<?php echo e(URL::action('ProductController@detail',['slug'=>$query->get_field_data('products',['id'=>$item->product_id],'slug')])); ?>" title="View Product" class="btn btn-default btn-xs">View</a></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>