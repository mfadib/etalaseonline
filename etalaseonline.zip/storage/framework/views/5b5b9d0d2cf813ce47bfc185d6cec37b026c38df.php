<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <h3>Register</h3>
            <?php echo Form::open(['method'=>'post','action'=>'MemberController@register','role'=>'form']); ?>

                <div class="form-group">
                    <?php echo Form::label('inputName','Name'); ?>

                    <?php echo Form::input('text','name',null,['class'=>'form-control','id'=>'inputName','placeholder'=>'Name']); ?>

                    <?php if($errors->has()): ?>
                        <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('inputEmail','Email'); ?>

                    <?php echo Form::email('email',null,['class'=>'form-control','id'=>'inputEmail','placeholder'=>'Email']); ?>

                    <?php if($errors->has()): ?>
                        <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('inputPassword','Password'); ?>

                    <?php echo Form::password('password',['class'=>'form-control','id'=>'inputPassword','placeholder'=>'Password']); ?>

                    <?php if($errors->has()): ?>
                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <?php echo Form::label('inputConfirm','Confirm'); ?>

                    <?php echo Form::password('confirm',['class'=>'form-control','id'=>'inputConfirm','placeholder'=>'Confirm']); ?>

                    <?php if($errors->has()): ?>
                        <p class="text-danger"><?php echo e($errors->first('confirm')); ?></p>
                    <?php endif; ?>
                </div>
                <?php echo Form::submit('Signup',['class'=>'btn btn-default']); ?>

                <p>a member? <a href="<?php echo e(URL::action('MemberController@signin')); ?>" title="Signin">Sign In</a></p>
            <?php echo Form::close(); ?>

            <br>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>