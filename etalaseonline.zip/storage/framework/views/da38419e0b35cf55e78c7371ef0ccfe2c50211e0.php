<?php if(Session::has('message_error')): ?>
    <div class="alert alert-danger">
        <?php echo Session::get('message_error'); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('message_success')): ?>
    <div class="alert alert-success">
        <?php echo Session::get('message_success'); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('message_warning')): ?>
    <div class="alert alert-warning">
        <?php echo Session::get('message_warning'); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('message_info')): ?>
    <div class="alert alert-info">
        <?php echo Session::get('message_info'); ?>

    </div>
<?php endif; ?>