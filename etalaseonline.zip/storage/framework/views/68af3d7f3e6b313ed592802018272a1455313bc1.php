<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">List News</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th style="width:20%;">Image</th>
							<th style="width:30%;">Title</th>
							<th style="width:40%;">Brief</th>
							<th style="width:5%;">Edit</th>
							<th style="width:5%;">Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($news as $item): ?>
						<tr>
							<td><img src="<?php echo e(URL::asset('images/news/'.$item->image)); ?>" alt="<?php echo e($item->title); ?>" class="img-thumbnail img-responsive"></td>
							<td><?php echo e($item->title); ?></td>
							<td><?php echo $item->brief; ?></td>
							<td><a href="<?php echo e(URL::action('AdminController@news_edit',['id'=>$item->id])); ?>" title="Edit" class="btn btn-info">Edit</a></td>
							<td>
								<?php echo Form::open(['action'=>'AdminController@news_delete','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

								<?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $news->links(); ?>

			</div>
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>