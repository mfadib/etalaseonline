<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">List Products</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th style="width:35%;">Title</th>
							<th style="width:40%;">How to buy</th>
							<th style="width:5%;text-align:center;">Reviews</th>
							<th style="width:5%;text-align:center;">Recommended</th>
							<th style="width:5%;text-align:center;">Special</th>
							<th style="width:5%;text-align:center;">Edit</th>
							<th style="width:5%;text-align:center;">Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($products as $item): ?>
						<tr>
							<td><?php echo e($item->title); ?></td>
							<td><?php echo $item->how_to_buy; ?></td>
							<td style="text-align:center;"><?php echo $query->get_data('reviews',['product_id'=>$item->id])->count(); ?></td>
							<td style="text-align:center;"><?php echo $query->get_yesno($item->recommended); ?></td>
							<td style="text-align:center;"><?php echo $query->get_yesno($item->special); ?></td>
							<td style="text-align:center;"><a href="<?php echo e(URL::action('AdminController@product_edit',['id'=>$item->id])); ?>" title="Edit" class="btn btn-info">Edit</a></td>
							<td style="text-align:center;">
								<?php echo Form::open(['action'=>'AdminController@product_delete','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

								<?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $products->links(); ?>

			</div>
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>