<?php $__env->startSection('header'); ?>
	<script src="<?php echo e(URL::asset('assets/js/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({ selector:'textarea'});
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Sliders</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-4">
		<h3>New Slide</h3>
		<?php echo Form::open(['action'=>'AdminController@slider_insert','method'=>'post','role'=>'form','files'=>true]); ?>

			<div class="form-group">
				<?php echo Form::label('image','Image'); ?>

              	<div class="col-md-12">
	                <?php echo Form::file('image',null,['placeholder'=>'Image','class'=>'form-control col-md-12 col-xs-12','required'=>true]); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('image'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('Status','Status'); ?>

              	<div class="col-md-12">
		            <div class="checkbox">
		                <label>
		                  <input name="status" value="1" type="checkbox"> Actived
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('status'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
		<?php echo Form::close(); ?>

		</div>
		<div class="col-md-8">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th style="width:75%;">Image</th>
							<th style="width:15%;">Status</th>
							<th style="width:5%;">Change</th>
							<th style="width:5%;">Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($sliders as $item): ?>
						<tr>
							<td>
							<img src="<?php echo e(URL::asset('images/sliders/'.$item->image)); ?>" alt="Slider" class="img-thumbnail img-responsive">
							<td><?php echo e($query->get_status($item->status)); ?></td>
							<td>
								<?php echo Form::open(['action'=>'AdminController@slider_status','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::hidden('status',$item->status); ?>

									<?php echo Form::submit('Change',['class'=>'btn btn-success']); ?>

								<?php echo Form::close(); ?>

							</td>
							<td>
								<?php echo Form::open(['action'=>'AdminController@slider_delete','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

								<?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $sliders->links();; ?>

			</div>
		</div>	
		<br><br><br>&nbsp;
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>