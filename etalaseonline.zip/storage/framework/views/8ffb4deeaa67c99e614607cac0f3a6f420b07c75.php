<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="">

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/jumbotron-narrow.css')); ?>">
        <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="https://use.fontawesome.com/dd09f69bca.js"></script>
    </head>
    <body>
        
        <div class="container">
            <div class="header clearfix">
                <nav>
                    <ul class="nav nav-pills pull-right">
                        <li role="presentation" <?php //  class="active" ?> ><a href="#">Home</a></li>
                        <li role="presentation"><a href="#">Products</a></li>
                        <li role="presentation"><a href="#">News</a></li>
                        <li role="presentation"><a href="#">About Us</a></li>
                        <li role="presentation"><a href="#">Login</a></li>
                    </ul>
                </nav>
                <h3 class="text-muted">Etalase Online</h3>
            </div>

            <div class="jumbotron">
                <h1>Jumbotron heading</h1>
                <p class="lead">Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
                <p><a class="btn btn-lg btn-success" href="#" role="button">Sign up today</a></p>
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/1.jpeg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div>  
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/2.jpeg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div> 
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/3.jpg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div> 
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
            </div>

            <footer class="footer">
                <p>&copy; 2016 Company, Inc.</p>
            </footer>

        </div> <!-- /container -->
    </body>
</html>

