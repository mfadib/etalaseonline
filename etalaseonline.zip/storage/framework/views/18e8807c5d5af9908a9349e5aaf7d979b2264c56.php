<!DOCTYPE html>
<html>
<head>
    <?php foreach($webprofile as $item): ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title_site','Admin area'); ?> | <?php echo e($item->title); ?></title>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo e(URL::asset('backend/plugins/bootstrap/bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('backend/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('backend/plugins/pace/pace-theme-big-counter.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('backend/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('backend/css/main-style.css')); ?>" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="<?php echo e(URL::asset('backend/plugins/morris/morris-0.4.3.min.css')); ?>" rel="stylesheet" />
    
    <link rel="icon" href="<?php echo e(URL::asset('assets/images/'.$item->icon)); ?>"/>
    <?php echo $__env->yieldContent('header'); ?>
   </head>
    <?php endforeach; ?>

<body>
    <!--  wrapper -->
    <div id="wrapper">
        <?php echo $__env->make('menus.admin_navbartop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('menus.admin_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--  page-wrapper -->
        <div id="page-wrapper">
            
            <?php echo $__env->yieldContent('h3'); ?>

            <div class="row">
                <!-- Welcome -->
                <div class="col-lg-12">
                    <?php echo $__env->make('messages.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <!--end  Welcome -->
            </div>
                
            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo e(URL::asset('backend/plugins/jquery-1.10.2.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/plugins/pace/pace.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/scripts/siminta.js')); ?>"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="<?php echo e(URL::asset('backend/plugins/morris/raphael-2.1.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/plugins/morris/morris.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/scripts/dashboard-demo.js')); ?>"></script>

    <?php echo $__env->yieldContent('footer'); ?>

</body>

</html>
