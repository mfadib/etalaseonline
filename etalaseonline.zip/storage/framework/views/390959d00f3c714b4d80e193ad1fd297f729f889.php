<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Edit User</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<?php echo Form::open(['action'=>'AdminController@user_update','method'=>'post','role'=>'form']); ?>

			<?php foreach($user->get() as $item): ?>
			<div class="form-group">
				<?php echo Form::label('name','name',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
              		<?php echo Form::hidden('id',$item->id); ?>

	               	<?php echo Form::text('name',$item->name,['placeholder'=>'name','class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('name'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('email','Email',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	               	<?php echo Form::email('email',$item->email,['placeholder'=>'Email','readonly'=>true,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('email'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			<h4>Change password</h4>
            <span class="label label-info">(Empty if not change)</span>
			<div class="form-group">
				<?php echo Form::label('old_password','Old Password',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	               	<?php echo Form::password('old_password',['placeholder'=>'Old Password','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('old_password'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('new_password','New Password',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	               	<?php echo Form::password('new_password',['placeholder'=>'New Password','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('new_password'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('confirm','Confrimation',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	               	<?php echo Form::password('confirm',['placeholder'=>'Confrimation','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('confirm'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-4">&nbsp;</div>
              	<div class="col-md-8">
		            <div class="checkbox">
		                <label>
		                  <input name="status" required="true" <?php if($item->status == 0): ?> checked <?php endif; ?> value="0" type="radio"> User
		                </label>
		                <label>
		                  <input name="status" required="true" <?php if($item->status == 1): ?> checked <?php endif; ?> value="1" type="radio"> Admin
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('status'); ?></span>
	                <?php endif; ?>
              	</div>
          	</div>

			<div class="form-group">
				<div class="col-md-4">&nbsp;</div>
              	<div class="col-md-8">
		            <div class="checkbox">
		                <label>
		                  <input name="actived" required="true" <?php if($item->actived == 0): ?> checked <?php endif; ?> value="0" type="radio"> Not Actived
		                </label>
		                <label>
		                  <input name="actived" required="true" <?php if($item->actived == 1): ?> checked <?php endif; ?> value="1" type="radio"> Actived
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('actived'); ?></span>
	                <?php endif; ?>
              	</div>
          	</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
			<?php endforeach; ?>
		<?php echo Form::close(); ?>

		<br><br><br>&nbsp;
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>