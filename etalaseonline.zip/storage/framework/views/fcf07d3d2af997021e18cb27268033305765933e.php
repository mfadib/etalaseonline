<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add News</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<?php echo Form::open(['action'=>'AdminController@news_insert','method'=>'post','role'=>'form','files'=>true]); ?>

			<div class="form-group">
				<?php echo Form::label('category_id','Category',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::select('category_id',$cats,null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('category_id'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('title','Title',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::hidden('id',null,['required'=>'required']); ?>

	                <?php echo Form::text('title',null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Title']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('title'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_description','Meta Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_description',null,['placeholder'=>'Meta Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_keywords','Meta Keywords',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_keywords',null,['placeholder'=>'Meta Keywords','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_keywords'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('brief','Brief',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('brief',null,['placeholder'=>'Brief','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('brief'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('description','Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('description',null,['placeholder'=>'Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('image','Image',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::file('image',['class'=>'form-control col-md-12 col-xs-12','required'=>true]); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('image'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-4">&nbsp;</div>
              	<div class="col-md-4">
		            <div class="checkbox">
		                <label>
		                  <input name="subscribe" value="1" type="checkbox"> Send Subscriber
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('subscribe'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
		<?php echo Form::close(); ?>

			<br><br><br>&nbsp;
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>