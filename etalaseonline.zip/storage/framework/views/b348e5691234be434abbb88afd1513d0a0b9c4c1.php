<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Add Product</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<?php echo Form::open(['action'=>'AdminController@product_insert','method'=>'post','role'=>'form','files'=>true]); ?>

			<div class="form-group">
				<?php echo Form::label('category_id','Category',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::select('category_id',$cats,null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('category_id'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('title','Title',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::hidden('id',null,['required'=>'required']); ?>

	                <?php echo Form::text('title',null,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Title']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('title'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_description','Meta Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_description',null,['placeholder'=>'Meta Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_keywords','Meta Keywords',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_keywords',null,['placeholder'=>'Meta Keywords','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_keywords'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('description','Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('description',null,['placeholder'=>'Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('how_to_buy','How to buy',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('how_to_buy',null,['placeholder'=>'How to buy','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('how_to_buy'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('price','Price',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::number('price',null,['placeholder'=>'Price','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('price'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-4">&nbsp;</div>
              	<div class="col-md-4">
		            <div class="checkbox">
		                <label>
		                  <input name="recommended" value="1" type="checkbox"> Recomended
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('recommended'); ?></span>
	                <?php endif; ?>
              	</div>
              	<div class="col-md-4">
		            <div class="checkbox">
		                <label>
		                  <input name="special" value="1" type="checkbox"> Special
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('special'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('cover','Cover',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::file('cover',['class'=>'form-control col-md-12 col-xs-12','required'=>true]); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('cover'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('images','Images',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::file('images[]',['multiple'=>true,'class'=>'form-control col-md-12 col-xs-12','required'=>true]); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('images'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-4">&nbsp;</div>
              	<div class="col-md-4">
		            <div class="checkbox">
		                <label>
		                  <input name="subscribe" value="1" type="checkbox"> Send Subscriber
		                </label>
		            </div>
					<?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('subscribe'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
		<?php echo Form::close(); ?>

			<br><br><br>&nbsp;
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>