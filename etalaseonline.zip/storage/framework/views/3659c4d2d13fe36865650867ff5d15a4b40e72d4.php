<div class="header clearfix">
    <nav>
        <ul class="nav nav-pills pull-right">
            <li role="presentation"><a href="<?php echo e(URL::action('HomeController@index')); ?>">Home</a></li>
            <li role="presentation"><a href="<?php echo e(URL::action('ProductController@index')); ?>">Products</a></li>
            <li role="presentation"><a href="<?php echo e(URL::action('NewsController@index')); ?>">News</a></li>
        </ul>
    </nav>
    <h3 class="text-muted">Etalase Online</h3>
</div>