<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Profile</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<h3>Change your website profile</h3>
		<?php echo Form::open(['action'=>'AdminController@profile_save','method'=>'post','role'=>'form','files'=>true]); ?>

			<?php foreach($webprofile->get() as $item): ?>
			<div class="form-group">
				<?php echo Form::label('title','Title website',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::hidden('id',$item->id,['required'=>'required']); ?>

	                <?php echo Form::text('title',$item->title,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Title']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('title'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('subtitle','Subtitle',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('subtitle',$item->subtitle,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Subtitle']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('subtitle'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('author','Author',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('author',$item->author,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Author']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('author'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_description','Meta Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_description',$item->meta_description,['placeholder'=>'Meta Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_keywords','Meta Keywords',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_keywords',$item->meta_keywords,['placeholder'=>'Meta Keywords','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_keywords'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('about','About',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('about',$item->about,['placeholder'=>'About','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('about'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('phone','Phone Numbers',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('phone',$item->phone,['placeholder'=>'Phone Numbers','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('phone'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('email','Email',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('email',$item->email,['placeholder'=>'Email','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('email'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('facebook','Facebook',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('facebook',$item->facebook,['placeholder'=>'Facebook','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('facebook'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('googleplus','Google Plus',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('googleplus',$item->googleplus,['placeholder'=>'Google Plus','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('googleplus'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('twitter','Twitter',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('twitter',$item->twitter,['placeholder'=>'Twitter','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('twitter'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('instagram','Instagram',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('instagram',$item->instagram,['placeholder'=>'Instagram','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('instagram'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('linkedin','Linkedin',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('linkedin',$item->linkedin,['placeholder'=>'Linkedin','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('linkedin'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('icon','icon',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <img src="<?php echo e(URL::asset('images/'.$item->icon)); ?>" class="img-thumbnail img-responsive" alt="<?php echo e($item->title); ?>">
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('icon','Change icon',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::file('icon',['placeholder'=>'icon','class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('icon'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
			<?php endforeach; ?>
		<?php echo Form::close(); ?>

			<br><br><br>&nbsp;
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>