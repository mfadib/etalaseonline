<!DOCTYPE html>
<html>
    <head>
        <title>Etalase Online</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="">

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/jumbotron-narrow.css')); ?>">
        <script src="<?php echo e(url('assets/js/jquery-1.10.2.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="https://use.fontawesome.com/dd09f69bca.js"></script>
        <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
        <?php echo $__env->yieldContent('header'); ?>
    </head>
    <body>
        
        <div class="container">
            <?php echo $__env->make('menus.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Global Message -->
            <?php echo $__env->make('messages.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- END Global Message -->
            
            <div class="row">
                <?php echo $__env->make('menus.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-md-9">
                    <!-- This is content of website -->
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- End content of website -->
                </div>
            </div>  
            <footer class="footer">
                <p>&copy; 2016 Company, Inc. | <a href="<?php echo e(URL::action('HomeController@page',['slug'=>'about-us'])); ?>" title="About Us">About Us</a> | <a href="<?php echo e(URL::action('HomeController@faqs')); ?>" title="FAQs">FAQs</a></p>
            </footer>

        </div> <!-- /container -->
        <?php echo $__env->yieldContent('footer'); ?>
    </body>
</html>

