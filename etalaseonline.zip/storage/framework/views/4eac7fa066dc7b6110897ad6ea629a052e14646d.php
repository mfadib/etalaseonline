<?php $__env->startSection('content'); ?>
            <div class="jumbotron">
                <h1>Etalase Product Online</h1>
                <p class="lead">this website for view all our products</p>
                <!-- <p><a class="btn btn-lg btn-success" href="#" role="button">Sign up today</a></p> -->
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/1.jpeg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div>  
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/2.jpeg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div> 
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
                <div class="col-lg-4">
                    <div>
                        <img src="<?php echo e(url('images/products/3.jpg')); ?>" style="width:100%;max-height: 200px;" class="img-thumbnail img-responsive" alt="Image alternative">
                    </div> 
                    <h4>Subheading</h4>
                    <p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum.</p>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>