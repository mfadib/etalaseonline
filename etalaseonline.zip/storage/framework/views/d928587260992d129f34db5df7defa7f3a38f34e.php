<p>Hello <?php echo e($name); ?>, </p>
<p>Account member</p>
<p>Email : <?php echo e($email); ?></p>
<p>Password : <?php echo e($password); ?></p>