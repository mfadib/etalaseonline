<?php $__env->startSection('titlebar'); ?>
      <div class="row">
        <div class="container">
          <div class="col-md-12 p10">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('HomeController@index')); ?>" class="cb">Home</a></li>
              <li class="breadcrumb-item active"><b>Products</b></li>
            </ol>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>

	<div class="row">

            <?php if(Auth::check()): ?>
              <?php if(Auth::user()->status == 0): ?>
                <?php $__env->startSection('sidebar_left'); ?>

		            <div style="border: 1px solid #ccc">
  						<div class="f16 bg p10 cw">CATEGORY</div>
		            	<div class="p10">
							<div><a href="<?php echo e(url('products')); ?>">All Category (<?php echo e($query->get_data('products')->count()); ?>)</a></div>
							<?php foreach($categories as $item): ?>
							<div><a href="<?php echo e(url('product/category/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($query->get_data('products',['category_id'=>$item->id])->count()); ?>)</a></div>
							<?php endforeach; ?>
		              	</div>
		            </div>
				<?php $__env->stopSection(); ?>
              <?php endif; ?>
          		<div class="col-md-12 col-xs-12 p10" style="margin-top: -20px">
            <?php else: ?>
	          <div class="col-md-3 top-nav">
	            <div style="border: 1px solid #ccc">
	            	<div class="f16 bg p10 cw">CATEGORY</div>
	            	<div class="p10">
						<div><a href="<?php echo e(url('products')); ?>">All Category (<?php echo e($query->get_data('products')->count()); ?>)</a></div>
						<?php foreach($categories as $item): ?>
						<div><a href="<?php echo e(url('product/category/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($query->get_data('products',['category_id'=>$item->id])->count()); ?>)</a></div>
						<?php endforeach; ?>
	              	</div>
	            </div>
	          </div>
          		<div class="col-md-9 col-xs-12 p10" style="margin-top: -20px">
            <?php endif; ?>
            <div class="p10">

            <div class="row">
              <span class="f16 ml20"><b>All Category</b></span>
            </div>

			<?php foreach($products as $product): ?>
              <div class="col-md-3 col-sm-4 col-xs-12 p10">
                <div class="">
                  <div class="bg open-hidden" style="height: 200px; width: 100%; background: url(<?php echo e(url('images/products/'.$product->cover)); ?>); background-size: cover; background-position: center;">
                    <div class="this-hidden none" style="background: rgba(0,0,0,0.4); height: 100%; width: 100%;">
                      <div class="cw">
                        <div class="wicon right">
                          <div class="mr10 mt10" style="margin-left: 40px;">
                            <span class="fa-stack fa-lg open-btn-compare"><a href="<?php echo e(url('product/detail/'.$product->slug)); ?>" title="Product detail" class="cw">
                              <i class="fa fa-circle-thin fa-stack-2x"></i>
                              <i class="fa fa-eye fa-stack-1x"></i></a>
                            </span>
                          </div>

                          <div style="margin-top: -36px">
                            <span class="fa-stack fa-lg"><a href="<?php echo e(url('product/wishlist/'.$product->slug)); ?>" title="Wishlist" class="cw">
                              <i class="fa fa-circle-thin fa-stack-2x"></i>
                              <i class="fa fa-heart fa-stack-1x"></i></a>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tc fprod"><a href="<?php echo e(url('product/detail/'.$product->slug)); ?>" class="cb" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></a></div>
                  <div class="tc fprod"><b><?php echo e($query->currency_format($product->price)); ?></b></div>
                </div>
              </div>
			<?php endforeach; ?>
              
              	<div class="col-xs-12 col-md-4 right p10">
	                <div class="tr">
						<?php echo e($products->links()); ?>

	                </div>
              	</div>

            </div>
        </div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>