<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">List User</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th style="width:20%;">Name</th>
							<th style="width:20%;">Type</th>
							<th style="width:30%;">Email</th>
							<th style="width:10%;">Actived</th>
							<th style="width:10%;text-align: center;">Status</th>
							<th style="width:5%;text-align: center;">Edit</th>
							<th style="width:5%;text-align: center;">Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($users as $item): ?>
						<tr>
							<td><?php echo e($item->name); ?></td>
							<td><?php echo e($query->get_usertype($item->status)); ?></td>
							<td><?php echo e($item->email); ?></td>
							<td><?php echo e($query->get_status($item->actived)); ?></td>
							<td>
								<?php echo Form::open(['action'=>'AdminController@user_actived','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::hidden('actived',$item->actived); ?>

									<?php echo Form::submit('Change active',['class'=>'btn btn-success']); ?>

								<?php echo Form::close(); ?>

							</td>
							<td><a href="<?php echo e(URL::action('AdminController@user_edit',['id'=>$item->id])); ?>" title="Edit" class="btn btn-info">Edit</a></td>
							<td>
								<?php echo Form::open(['action'=>'AdminController@user_delete','method'=>'post']); ?>

									<?php echo Form::hidden('id',$item->id); ?>

									<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

								<?php echo Form::close(); ?>

							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $users->links(); ?>

			</div>
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>