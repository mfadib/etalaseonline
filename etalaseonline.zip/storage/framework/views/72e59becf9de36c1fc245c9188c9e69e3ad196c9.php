<div class="header clearfix">
    <nav>
        <ul class="nav nav-pills pull-right">
            <li role="presentation"><a href="<?php echo e(URL::action('HomeController@index')); ?>">Home</a></li>
            <li role="presentation"><a href="<?php echo e(URL::action('ProductController@index')); ?>">Products</a></li>
            <li role="presentation"><a href="<?php echo e(URL::action('NewsController@index')); ?>">News</a></li>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->status == 0): ?>
                    <li role="presentation"><a href="<?php echo e(URL::action('MemberController@memberarea')); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                    <li role="presentation"><a href="<?php echo e(URL::action('MemberController@signout')); ?>">Logout</a></li>
                <?php endif; ?>
            <?php else: ?>
            <li role="presentation"><a href="<?php echo e(URL::action('MemberController@signin')); ?>">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <h3 class="text-muted">Etalase Online</h3>
</div>
