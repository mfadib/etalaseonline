<?php $__env->startSection('content'); ?>
  <div class="col-md-12 p10">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(URL::action('HomeController@index')); ?>" class="cb">Home</a></li>
      <li class="breadcrumb-item active"><b>News</b></li>
    </ol>
  </div>
	<div class="row">
            <?php if(Auth::check()): ?>
              <?php if(Auth::user()->status == 0): ?>
                <?php $__env->startSection('sidebar_left'); ?>

		            <div style="border: 1px solid #ccc">
  						<div class="f16 bg p10 cw">CATEGORY</div>
		            	<div class="p10">
							<div><a href="<?php echo e(url('news')); ?>">All</a></div>
							<?php foreach($categories->get() as $item): ?>
							<div><a href="<?php echo e(url('news/category/'.$item->slug)); ?>"><?php echo e($item->name); ?></a></div>
							<?php endforeach; ?>
		              	</div>
		            </div>
				<?php $__env->stopSection(); ?>
              <?php endif; ?>
          		<div class="col-md-12 col-xs-12 p10" style="margin-top: -20px">
            <?php else: ?>
	          <div class="col-md-3 top-nav">
	            <div style="border: 1px solid #ccc">
	            	<div class="f16 bg p10 cw">CATEGORY</div>
	            	<div class="p10">
						<div><a href="<?php echo e(url('news')); ?>">All</a></div>
						<?php foreach($categories->get() as $item): ?>
						<div><a href="<?php echo e(url('news/category/'.$item->slug)); ?>"><?php echo e($item->name); ?></a></div>
						<?php endforeach; ?>
	              	</div>
	            </div>
	          </div>
          		<div class="col-md-9 col-xs-12 p10" style="margin-top: -20px">
            <?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<?php foreach($news->get() as $pro): ?>
					<h3><?php echo e($pro->title); ?></h3><hr>
					<div class="row">
						<div class="row">
							<div class="col-md-12">
								<img src="<?php echo e(url('images/news/'.$pro->image)); ?>" class="img img-thumbnail img-resposive" alt="<?php echo e($pro->title); ?>">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<h4>Description</h4>
								<?php echo $pro->description; ?>

								<hr>
								<a href="<?php echo e($shares['email']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-envelope-o"></i> Email</a>
								<a href="<?php echo e($shares['facebook']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-facebook"></i> Facebook</a>
								<a href="<?php echo e($shares['twitter']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-twitter"></i> Twitter</a>
								<a href="<?php echo e($shares['gplus']); ?>" title="<?php echo e($pro->title); ?>" class="btn btn-default btn-xs"><i class="fa fa-google-plus"></i> Google Plus</a>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php /* <div class="row">
				<div class="col-md-12">
					<h3>Related News</h3><hr>
					<div class="row">
						<?php foreach($relations->get() as $item): ?>
							<div class="col-md-3">
								<img src="<?php echo e(url('images/news/'.$item->image)); ?>" class="img img-thumbnail img-resposive" alt="<?php echo e($item->title); ?>">
								<a href="<?php echo e(url('news/detail/'.$item->slug)); ?>" title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>*/ ?>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>