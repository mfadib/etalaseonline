<p>Hello <?php echo e($name); ?>, </p>
<p>Confirmation your email <a href="<?php echo e(url('member/confirm/'.$confirm)); ?>" title="">click here</a></p>
<p>or copy and paste this url <b><?php echo e(url('member/confirm/'.$confirm)); ?></b></p>