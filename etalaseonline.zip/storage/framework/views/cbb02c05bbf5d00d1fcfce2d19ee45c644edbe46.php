<?php $__env->startSection('h3'); ?>
	<div class="row">
        <!-- Page Header -->
        <div class="col-lg-12">
            <h1 class="page-header">Edit News</h1>
        </div>
        <!--End Page Header -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<?php echo Form::open(['action'=>'AdminController@news_update','method'=>'post','role'=>'form','files'=>true]); ?>

			<?php foreach($news->get() as $item): ?>
			<div class="form-group">
				<?php echo Form::label('category_id','Category',['class'=>'control-label col-md-4']); ?>

				<div class="col-md-8">
              		<?php echo Form::hidden('id',$item->id); ?>

	                <?php echo Form::select('category_id',$cats,$item->category_id,['class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('category_id'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>
			
			<div class="form-group">
				<?php echo Form::label('title','Title',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::text('title',$item->title,['class'=>'form-control col-md-12 col-xs-12','required'=>'required','placeholder'=>'Title']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('title'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_description','Meta Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_description',$item->meta_description,['placeholder'=>'Meta Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('meta_keywords','Meta Keywords',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('meta_keywords',$item->meta_keywords,['placeholder'=>'Meta Keywords','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('meta_keywords'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('brief','Brief',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('brief',$item->brief,['placeholder'=>'Brief','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('brief'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('description','Description',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::textarea('description',$item->description,['placeholder'=>'Description','rows'=>7,'class'=>'form-control col-md-12 col-xs-12','required'=>'required']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('description'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('image','Image',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <img src="<?php echo e(URL::asset('images/news/'.$item->image)); ?>" alt="<?php echo e($item->title); ?>" class="img-thumbnail img-responsive">
              	</div>
			</div>

			<div class="form-group">
				<?php echo Form::label('image','Change Image',['class'=>'control-label col-md-4']); ?>

              	<div class="col-md-8">
	                <?php echo Form::file('image',['class'=>'form-control col-md-12 col-xs-12']); ?>

	                <?php if($errors->has()): ?>
	                    <span class="label label-danger"><?php echo $errors->first('image'); ?></span>
	                <?php endif; ?>
              	</div>
			</div>

			<div class="form-group">
				<div class="col-md-8 col-md-offset-4">
	                <?php echo Form::submit('Save',['class'=>'btn btn-default']); ?>

              	</div>
			</div>
			<?php endforeach; ?>
		<?php echo Form::close(); ?>

			<br><br><br>&nbsp;
		</div>
	</div>			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>