<?php $__env->startSection('titlebar'); ?>
      <div class="row">
        <div class="container">
          <div class="col-md-12 p10">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('HomeController@index')); ?>" class="cb">Home</a></li>
              <li class="breadcrumb-item active"><b>FAQs</b></li>
            </ol>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			
			<?php foreach($faqs->get() as $item): ?>
				<div class="panel panel-default">
					<div class="panel-body">
						<p><?php echo $item->question; ?></p>
						<blockquote class="pull-right"><?php echo $item->answer; ?></blockquote>	
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>