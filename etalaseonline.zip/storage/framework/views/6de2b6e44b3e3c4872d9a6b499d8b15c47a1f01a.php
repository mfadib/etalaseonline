<?php $__env->startSection('titlebar'); ?>
      <div class="row">
        <div class="container">
          <div class="col-md-12 p10">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(URL::action('MemberController@memberarea')); ?>" class="cb">Member Area</a></li>
              <li class="breadcrumb-item active"><b>Settings</b></li>
            </ol>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<h3>Your Profile</h3><hr>
			<?php echo Form::open(['action'=>'MemberController@change_password','method'=>'post']); ?>

				<?php echo Form::hidden('id',Auth::user()->id); ?>

					<div class="form-group">
						<?php echo Form::label('name','Name'); ?>

						<?php echo Form::text('name',Auth::user()->name,['class'=>'form-control','id'=>'name','readonly'=>true]); ?>

				        <?php if($errors->has()): ?>
				            <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
				        <?php endif; ?>
				    </div>
					<div class="form-group">
						<?php echo Form::label('email','Email'); ?>

						<?php echo Form::email('old',Auth::user()->email,['class'=>'form-control','id'=>'email','readonly'=>true]); ?>

				        <?php if($errors->has()): ?>
				            <p class="text-danger"><?php echo e($errors->first('old')); ?></p>
				        <?php endif; ?>
				    </div>
				    <h3>Change Password</h3><hr>
					<div class="form-group">
						<?php echo Form::label('oldpassword','Old Password'); ?>

						<?php echo Form::password('old',['class'=>'form-control','id'=>'oldpassword']); ?>

				        <?php if($errors->has()): ?>
				            <p class="text-danger"><?php echo e($errors->first('old')); ?></p>
				        <?php endif; ?>
				    </div>
					<div class="form-group">
						<?php echo Form::label('newpassword','New Password'); ?>

						<?php echo Form::password('new',['class'=>'form-control','id'=>'newpassword']); ?>

				        <?php if($errors->has()): ?>
				            <p class="text-danger"><?php echo e($errors->first('new')); ?></p>
				        <?php endif; ?>
				    </div>
					<div class="form-group">
						<?php echo Form::label('confirm','Confirm'); ?>

						<?php echo Form::password('confirm',['class'=>'form-control','id'=>'confirm']); ?>

				        <?php if($errors->has()): ?>
				            <p class="text-danger"><?php echo e($errors->first('confirm')); ?></p>
				        <?php endif; ?>
				    </div>
				<?php echo Form::submit('Change',['class'=>'btn btn-default']); ?>

			<?php echo Form::close(); ?>

		</div>
	</div><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>