<p>Hello, we have new post </p>
<p>Please check this url <a href="{{$url}}" title="">click here</a></p>
<p>or copy and paste this url <b>{{$url}}</b></p>