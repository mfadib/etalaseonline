<p>Hello Subscriber, </p>
<p>To stop subscribe <a href="{{$url}}" title="">click here</a></p>
<p>or copy and paste this url <b>{{$url}}</b></p>