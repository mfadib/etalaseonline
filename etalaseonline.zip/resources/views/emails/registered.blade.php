<p>Hello {{$name}}, </p>
<p>Confirmation your email <a href="{{url('member/confirm/'.$confirm)}}" title="">click here</a></p>
<p>or copy and paste this url <b>{{url('member/confirm/'.$confirm)}}</b></p>