<p>Hello {{$name}}, </p>
<p>Account member</p>
<p>Email : {{$email}}</p>
<p>Password : {{$password}}</p>