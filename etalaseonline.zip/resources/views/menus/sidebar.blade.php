<div class="col-md-3">
    <ul class="nav bs-sidenav">
        <li><a href="{{URL::action('MemberController@reviews')}}">Product</a></li>
        <li><a href="{{URL::action('MemberController@wishlist')}}">News</a></li>
        <li class="li-separated"></li>
        <li><a href="{{URL::action('MemberController@setting')}}">Setting</a></li>
    </ul>
    <br>
</div>